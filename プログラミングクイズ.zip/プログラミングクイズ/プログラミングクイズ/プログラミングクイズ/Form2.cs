﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace プログラミングクイズ
{
    public partial class QuizForm : Form
    {
        //DB接続情報
        public static string connectionString =
            "Host = localhost;"
            + "Port = 5432;"
            + "Username = postgres;"
            + "Password= gododb4600;"
            + "Database=programming quiz; ";

        private Label lblQuestion;
        private RadioButton rdoOption1;
        private RadioButton rdoOption2;
        private RadioButton rdoOption3;
        private RadioButton rdoOption4;
        private int correctOptionIndex;
        private Button btnSubmit;
        private Button btnNext;
        private Button btnExitQuiz;
        private Timer timer;
        private int colorIndex = 0;
        private Color[] nightcolors = {
                Color.LightSkyBlue,
                Color.MediumOrchid,
                Color.LightCoral,
                Color.Gold,
                Color.RosyBrown,
                Color.DarkSlateBlue,
                Color.BurlyWood,
                Color.Sienna,
                Color.Crimson,
                Color.SlateGray,
                Color.LavenderBlush,
                Color.CadetBlue
            };
        private float offsetX = 0; // スクロールの位置
        private float scrollSpeed = 0.5f; // ゆっくりスクロールする速度

        // ✨ 背景の変化をスムーズにするための追加変数
        private float colorTransitionProgress = 0f; // 色の変化進行度
        private int backgroundChangeCounter = 0; // 背景変更のカウンター
        private int backgroundChangeInterval = 30; // 背景色の変更頻度    
        private float transitionSpeed = 0.002f; // 色の変化速度（遷移を滑らかに）
        public QuizForm()
            {
            // 初期化処理
                InitializeComponent();
                InitializeUI();
                LoadAllQuestions();
                AddButtonFadeInEffect();
                timer = new Timer();
                timer.Interval = 50;
                timer.Tick += Timer_Tick;
                timer.Start();
                this.Load += QuizForm_Load;
                this.DoubleBuffered = true;
            }
        private void QuizForm_Load(object sender, EventArgs e)
            {
            AddButtonFadeInEffect();
            }

        private void InitializeUI()
        {
            this.BackColor = Color.MistyRose;
            this.Size = new Size(800, 600);
            lblQuestion = new Label()
            {
                Location = new Point(20, 20),
                Width = 700,
                Font = new Font("Yu Mincho", 14, FontStyle.Bold),
            };

            lblQuestion.BackColor = Color.Transparent;
            lblQuestion.BorderStyle = BorderStyle.None;
            lblQuestion.ForeColor = Color.White; // 明るい背景でも見えるように

            rdoOption1 = new RadioButton() { Location = new Point(50, 150), AutoSize = true };
            rdoOption2 = new RadioButton() { Location = new Point(50, 200), AutoSize = true };
            rdoOption3 = new RadioButton() { Location = new Point(50, 250), AutoSize = true };
            rdoOption4 = new RadioButton() { Location = new Point(50, 300), AutoSize = true };

            rdoOption1.FlatStyle = FlatStyle.System;
            rdoOption2.FlatStyle = FlatStyle.System;
            rdoOption3.FlatStyle = FlatStyle.System;
            rdoOption4.FlatStyle = FlatStyle.System;

            rdoOption1.BackColor = Color.Transparent;
            rdoOption2.BackColor = Color.Transparent;
            rdoOption3.BackColor = Color.Transparent;
            rdoOption4.BackColor = Color.Transparent;

            rdoOption1.CheckedChanged += RadioButton_CheckedChanged;
            rdoOption2.CheckedChanged += RadioButton_CheckedChanged;
            rdoOption3.CheckedChanged += RadioButton_CheckedChanged;
            rdoOption4.CheckedChanged += RadioButton_CheckedChanged;

            btnSubmit = new Button()
            {
                Text = "天使の微笑み",
                Location = new Point(30, 400),
                Size = new Size(150, 50),
                BackColor = Color.MediumSlateBlue,
                ForeColor = Color.White,
                Font = new Font("Yu Mincho", 12, FontStyle.Bold),
            };
            btnSubmit.Click += BtnSubmit_Click;

            btnNext = new Button()
            {
                Text = "人生の扉を開ける",
                Location = new Point(200, 400),
                Size = new Size(160, 50),
                BackColor = Color.LightGoldenrodYellow,
                ForeColor = Color.DarkOrange,
                Font = new Font("Yu Mincho", 12, FontStyle.Bold),
                Enabled = false,
            };
            btnNext.Click += BtnNext_Click;

            this.Controls.Add(lblQuestion);
            this.Controls.Add(rdoOption1);
            this.Controls.Add(rdoOption2);
            this.Controls.Add(rdoOption3);
            this.Controls.Add(rdoOption4);
            this.Controls.Add(btnSubmit);
            this.Controls.Add(btnNext);

            btnExitQuiz = new Button()
            {
                Text = "少し休んで\n次のチャプターへ", // 穏やかで優しい表現
                Location = new Point(480, 400), // ボタン位置を調整
                Size = new Size(200, 60), // 少し大きめで柔らかな印象に
                BackColor = Color.PaleVioletRed, // 優しい赤系の配色
                ForeColor = Color.White, // テキストをシンプルに白に
                Font = new Font("Yu Mincho", 14, FontStyle.Bold) // 優雅で昭和レトロ感のあるフォント
            };

            btnExitQuiz.Click += BtnExitQuiz_Click;
            this.Controls.Add(btnExitQuiz);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            try
            {
                e.Graphics.Clear(Color.MistyRose); // 背景を明示的に指定！
                DrawBackground(e.Graphics); // Graphicsオブジェクトを直接渡す
                DrawBuildings(e.Graphics);
                DrawStars(e.Graphics);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"描画処理中にエラー発生: {ex.Message}");
            }
        }

        private void DrawStars(Graphics g)
        {
            Random rand = new Random();
            for (int i = 0; i < 150; i++)
            {
                int x = rand.Next(this.Width);
                int y = rand.Next(this.Height / 4);
                int size = rand.Next(2, 5);
                int alpha = (int)(Math.Sin(Environment.TickCount / 700.0 * Math.PI) * 70 + 180);
                alpha -= (y / (this.Height / 4)) * 50;
                alpha = Math.Max(0, Math.Min(255, alpha));

                // ゴールド系の輝きに変更
                Color sparkleColor = Color.FromArgb(alpha, rand.Next(200, 255), rand.Next(180, 220), rand.Next(100, 150));

                using (SolidBrush sparkleBrush = new SolidBrush(sparkleColor))
                {
                    g.FillEllipse(sparkleBrush, x, y, size, size);
                }
            }
        }

        private void DrawSparkles(Graphics g)
        {
            Random rand = new Random();
            for (int i = 0; i < 100; i++)
            {
                int x = rand.Next(this.Width / 3, this.Width);
                int y = rand.Next(this.Height / 2);
                int size = rand.Next(3, 7); // ⭐ 少しサイズアップ

                int alpha = rand.Next(180, 255); // ✨ ランダムで輝き変化
                Color sparkleColor = Color.FromArgb(alpha, 240, 240, 255); // 🌌 夜空の星の色に近づける

                using (SolidBrush sparkleBrush = new SolidBrush(sparkleColor))
                {
                    g.FillEllipse(sparkleBrush, x, y, size, size);
                }
            }
        }

        // 🎨 問題文の色を背景によって調整
        private void AdjustTextColor()
        {
            float brightness = nightcolors[colorIndex].GetBrightness();
            lblQuestion.ForeColor = brightness < 0.5 ? Color.White : Color.Black; // 明るさに応じて変更
        }

        private void DrawBackground(Graphics g)
        {
            using (Brush skyBrush = new SolidBrush(GetSmoothTransitionColor()))
            {
                g.FillRectangle(skyBrush, this.ClientRectangle);
            }
        }

        // 🏢 **建物・街灯・ベンチ・看板のスクロール**
        private void DrawBuildings(Graphics g)
        {
            try
            {
                int baseY = this.Height - 400;
                int buildingX = (int)(this.Width - 500 - offsetX * 1.0); // **建物のスクロール速度を基準に！**

                Brush buildingBrush = Brushes.DarkSlateGray;
                Brush windowBrush = new SolidBrush(Color.FromArgb(180, Color.LightGoldenrodYellow));

                // 🏠 **建物を正しい位置に描画**
                g.FillRectangle(buildingBrush, new Rectangle(buildingX, baseY, 80, 150)); // 建物1
                g.FillRectangle(buildingBrush, new Rectangle(buildingX + 100, baseY + 10, 100, 130)); // 建物2
                g.FillRectangle(buildingBrush, new Rectangle(buildingX + 220, baseY - 30, 120, 170)); // 建物3

                // 🏮 **街灯を建物と一緒にスクロール**
                int lampX = (int)(buildingX - 60 - offsetX * 1.0);
                g.FillRectangle(buildingBrush, new Rectangle(lampX, baseY + 50, 10, 100));
                g.FillEllipse(Brushes.LightGoldenrodYellow, new Rectangle(lampX - 5, baseY + 30, 20, 20));

                // 🪑 **ベンチを建物と一緒にスクロール**
                Brush benchBrush = Brushes.SaddleBrown;
                int benchX = (int)(buildingX - 100 - offsetX * 1.0);
                g.FillRectangle(benchBrush, new Rectangle(benchX, baseY + 150, 80, 10)); // 座面
                g.FillRectangle(benchBrush, new Rectangle(benchX + 5, baseY + 160, 10, 20)); // 左脚
                g.FillRectangle(benchBrush, new Rectangle(benchX + 65, baseY + 160, 10, 20)); // 右脚

                // ✅ **看板を建物の右側に調整**
                int signPoleX = buildingX + 300; 
                int signPoleY = baseY + 50; // 看板の高さを固定

                // ポールの描画
                g.FillRectangle(buildingBrush, new Rectangle(signPoleX + 105, signPoleY, 10, 100));

                // 看板の板を描画
                g.FillRectangle(Brushes.Beige, new Rectangle(signPoleX + 50, signPoleY - 50, 120, 50));

               // 看板の文字を波線状に配置
            using (Font font = new Font("Yu Mincho", 8, FontStyle.Bold)) // サイズを調整
            {
                string[] textLines = { "竹内まりやの世界へ", "ようこそ" }; // 二行のテキスト
                Brush textBrush = Brushes.Red; // 文字の色を定義

                float startX = signPoleX + 51;
                float startY = signPoleY - 45; 
                float waveAmplitude = 5f; // 波の振幅
                float waveFrequency = 0.6f; // 波の周波数

                for (int i = 0; i < textLines.Length; i++) // 各行を描画
                {
                    string line = textLines[i];
                    for (int j = 0; j < line.Length; j++) // 各文字を描画
                    {
                        string character = line[j].ToString(); // 1文字ずつ取得
                        SizeF charSize = g.MeasureString(character, font);

                        // X座標とY座標を計算
                        float charX = startX + j * (charSize.Width - 1.5f); // 文字間隔を微調整
                        float charY = startY + i * 20 + (float)(Math.Sin(j * waveFrequency) * waveAmplitude); // 波状配置

                        // 文字を描画
                        g.DrawString(character, font, textBrush, charX, charY);
                    }
                }
            }
                            
            }
            catch (Exception ex)
            {
                Console.WriteLine($"建物描画中にエラー発生: {ex.Message}");
            }
        }

        // 🔄 スクロール処理（ずっと動くようにする）
        private void Timer_Tick(object sender, EventArgs e)
        {
            try
            {
                offsetX += scrollSpeed;
                if (offsetX > this.Width) offsetX = 0;

                backgroundChangeCounter++;
                if (backgroundChangeCounter >= backgroundChangeInterval)
                {
                    colorIndex = (colorIndex + 1) % nightcolors.Length;
                    backgroundChangeCounter = 0;
                }

                colorTransitionProgress += transitionSpeed;
                if (colorTransitionProgress > 1f) colorTransitionProgress = 0f;

                this.Invalidate(); // 再描画
            }
            catch (Exception ex)
            {
                Console.WriteLine($"スクロール処理中にエラー発生: {ex.Message}");
            }
        }

        private Color GetSmoothTransitionColor()
        {
            Color startColor = nightcolors[colorIndex];
            Color endColor = nightcolors[(colorIndex + 1) % nightcolors.Length];

            colorTransitionProgress += transitionSpeed;
            if (colorTransitionProgress > 1f) colorTransitionProgress = 0f;

            return BlendColors(startColor, endColor, colorTransitionProgress);
        }
        
        private (string question, List<string> options, int correctIndex) currentQuestion;
        private int selectedIndex = -1;

        private Timer fadeInTimer;
        private int opacityLevel = 0; // ボタンの初期透明度（0から100）

        private void AddButtonFadeInEffect()
        {
            fadeInTimer = new Timer();
            fadeInTimer.Interval = 10000; // 更新間隔（ミリ秒）
            fadeInTimer.Tick += Timer_Tick;
            fadeInTimer.Start();
        }

        private float gradientAngle = 0f; // グラデーション角度
               
        // 色を滑らかに混ぜるメソッド
        private Color BlendColors(Color color1, Color color2, float ratio)
        {
            int r = (int)(color1.R * ratio + color2.R * (1 - ratio));
            int g = (int)(color1.G * ratio + color2.G * (1 - ratio));
            int b = (int)(color1.B * ratio + color2.B * (1 - ratio));
            return Color.FromArgb(r, g, b);
        }
        
        private List<(string question, List<string> options, int correctIndex)> allQuestions; // 全問題を保持するリスト
            private int currentQuestionIndex = 0; // 現在の問題番号

        private void LoadAllQuestions()
        {
            allQuestions = new List<(string question, List<string> options, int correctIndex)>();

            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT question, option1, option2, option3, option4, correct_answer FROM quiz_questions";

                using (var command = new NpgsqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var question = reader.GetString(0);
                        var options = new List<string>
                {
                    reader.GetString(1),
                    reader.GetString(2),
                    reader.GetString(3),
                    reader.GetString(4)
                };
                        var correctIndex = Math.Max(0, Math.Min(3, reader.GetInt32(5) - 1));

                        allQuestions.Add((question, options, correctIndex));

                        // ✅ ⭐ デバッグログを追加
                        Console.WriteLine($"取得した問題: {question}");
                    }
                }
            }

            Console.WriteLine($"問題データの数: {allQuestions.Count}");

            allQuestions = allQuestions.OrderBy(q => Guid.NewGuid()).ToList(); // ランダム並び替え
            LoadNewQuestion(); // 最初の問題をロード
        }
         private void LoadNewQuestion()
        {
            // ✅ 全ての問題を解いたら終了！
            if (currentQuestionIndex >= allQuestions.Count)
            {
                MessageBox.Show(
                    "長い旅路を歩んできましたね。\n答えに迷いながらも、一歩ずつ進んできたあなたに、拍手を送りたいと思います。\nこのクイズの物語が終わっても、新しい扉はいつでも開かれています。\nどうか、あなたらしく輝く道を歩んでください。",
                    "人生の扉が開く瞬間",

                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                this.Close(); // 🔹 クイズを終了する
                return;
            }

            var current = allQuestions[currentQuestionIndex];

            lblQuestion.Text = current.question;
            lblQuestion.AutoSize = true;
            lblQuestion.MaximumSize = new Size(700, 0);

            var shuffledOptions = current.options.OrderBy(x => Guid.NewGuid()).ToList();
            correctOptionIndex = shuffledOptions.IndexOf(current.options[current.correctIndex]);

            rdoOption1.Text = shuffledOptions[0];
            rdoOption2.Text = shuffledOptions[1];
            rdoOption3.Text = shuffledOptions[2];
            rdoOption4.Text = shuffledOptions[3];

            rdoOption1.Checked = false;
            rdoOption2.Checked = false;
            rdoOption3.Checked = false;
            rdoOption4.Checked = false;

            btnNext.Enabled = false;

            // ✅ インデックスを確実に更新！
            currentQuestionIndex++;
        }
        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            if (selectedIndex == -1)
            {
                lblQuestion.Text = "答えを選んでください！";
                lblQuestion.ForeColor = Color.Red;
                return;
            }

            // ✅ デバッグ用ログ追加
            Console.WriteLine($"選択した答えのインデックス: {selectedIndex}");
            Console.WriteLine($"正解のインデックス: {correctOptionIndex}");

            if (selectedIndex == correctOptionIndex)
            {
                lblQuestion.Text = "正解！おめでとうございます！✨";
                lblQuestion.ForeColor = Color.Green;
            }
            else
            {
                lblQuestion.Text = "不正解でも大丈夫。あなたのペースで、一歩ずつ進んでいきましょう。💖";
                lblQuestion.ForeColor = Color.Red;
            }

            btnNext.Enabled = true;
        }

        private void BtnNext_Click(object sender, EventArgs e)
            {
                // 新しい問題をロード
                LoadNewQuestion();
            }

        private void BtnExitQuiz_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "クイズを終了してもよろしいですか？\nまた挑戦してくださいね。",
                "クイズ終了の確認",
                MessageBoxButtons.YesNoCancel, // ✅ 柔らかい選択肢を追加
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                MessageBox.Show(
                    "お疲れさまでした！\nまたお会いできるのを楽しみにしています。\n\n人生は旅のようなもの。今日のクイズが終わっても、あなたの物語はまだ続きます。\nどうか、あなたらしく輝きながら、素敵な時間を過ごしてくださいね。",
                    "ありがとう",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
                );
                this.Close();
            }
        }

        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoOption1.Checked) selectedIndex = 0;
            if (rdoOption2.Checked) selectedIndex = 1;
            if (rdoOption3.Checked) selectedIndex = 2;
            if (rdoOption4.Checked) selectedIndex = 3;

            Console.WriteLine($"選択された回答: {selectedIndex}"); // ✅ ログを追加（デバッグ用）
        }
    }
}


