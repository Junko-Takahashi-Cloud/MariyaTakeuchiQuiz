﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using プログラミングクイズ;

namespace プログラミングクイズ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // 温かいメッセージを設定
            Label lblWelcome = new Label();
            lblWelcome.Text = "プログラミングの旅へようこそ！\n一緒に新しい扉を開けましょう。";
            lblWelcome.Font = new Font("Yu Mincho", 18, FontStyle.Bold); // 優しい日本語フォント
            lblWelcome.ForeColor = Color.DarkRed; // ピンク系に合わせて深みのある赤
            lblWelcome.Size = new Size(this.ClientSize.Width, 100); // フォームの幅に合わせてラベルのサイズを調整
            lblWelcome.Location = new Point(0, 50); // ラベルをフォームの中央上部に配置
            lblWelcome.TextAlign = ContentAlignment.MiddleCenter; // テキストを中央揃えにする

            this.Controls.Add(lblWelcome); // フォームにラベルを追加


            // 背景色をピンク系に
            this.BackColor = Color.FromArgb(255, 228, 225); // 落ち着いたローズ系

            // スタートボタンのデザイン
            Button btnStart = new Button();
            btnStart.Text = "クイズ開始";
            btnStart.Font = new Font("Arial", 12, FontStyle.Bold); // ボタンフォント
            btnStart.ForeColor = Color.Maroon; // ボタン文字色
            btnStart.BackColor = Color.LightPink; // ボタン背景色
            btnStart.Size = new Size(200, 50); // 幅と高さの設定
            btnStart.Location = new Point((this.ClientSize.Width - btnStart.Width) / 2, this.ClientSize.Height - 220); // フォームの下部に配置
            this.Controls.Add(btnStart); // フォームにボタンを追加

            // 終了ボタンのデザイン（スタートボタンと統一）
            Button btnExit = new Button();
            btnExit.Text = "クイズ終了";
            btnExit.Font = new Font("Arial", 12, FontStyle.Bold); // 同じフォントスタイルに統一
            btnExit.ForeColor = Color.Maroon; // 同じ文字色に統一
            btnExit.BackColor = Color.MistyRose; // 優しいピンク系の背景
            btnExit.Size = new Size(200, 50); // 幅と高さの設定
            btnExit.Location = new Point((this.ClientSize.Width - btnExit.Width) / 2, this.ClientSize.Height - 100); // スタートボタンのさらに下に配置
            this.Controls.Add(btnExit);// スタートボタンのデザイン
            

            btnStart.Click += btnStart_Click;
            btnExit.Click += btnExit_Click;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                // クイズ画面に遷移
                QuizForm quizForm = new QuizForm();
                quizForm.ShowDialog(); // クイズ画面を表示
                this.Show(); // クイズ終了後にForm1を再表示
            }
            catch (Exception ex)
            {
                MessageBox.Show($"エラーが発生しました: {ex.Message}", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
